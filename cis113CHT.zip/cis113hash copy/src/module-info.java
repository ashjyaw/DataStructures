module cis113hash 
{
	/*
	 *this is pretty cool huh 
	 * 
	 */
}