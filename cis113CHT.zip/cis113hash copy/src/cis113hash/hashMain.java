package cis113hash;

import java.util.*;

public class hashMain {
	
	
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		
		System.out.println("HashTable with Strings and Integers");
		System.out.println("Enter size");
		
		ChainedHashNode userHash = new ChainedHashNode(scan.nextInt());
		
		char choice = 'Y';
		
		while(choice == 'Y' || choice == 'y')
		{
			
			System.out.println("\nHashTable functions\n");
			System.out.println("1. Insert");
			System.out.println("2. Whipe");
			System.out.println("3. Remove");
			System.out.println("4. Get");
			System.out.println("5. Size");
			int ch = scan.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("Enter key and value seperated by a space");
				userHash.insert(scan.next(), scan.nextInt());
				break;
			case 2:
				userHash.whipeOut();
				System.out.println("The entire hashTable has been cleared");
				break;
			case 3:
				System.out.println("Enter Key to be removed");
				userHash.remove(scan.next());
				break;
			case 4:
				System.out.println("Enter Key to retrieve data");
				userHash.get(scan.next());
				break;
			case 5:
				System.out.println(userHash.getSize());
				break;
			default:
				System.out.println("Enter a real option next time");
				break;
			}
			
			userHash.print();		
			System.out.println("\nContinue Y or N");
			choice = scan.next().charAt(0); //this way it only scans the first letter of whats entered
		}
		
		scan.close();
	}

}
