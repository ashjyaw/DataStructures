package cis113hash;

public class HashNode// simple object class with constructor to store values 
{	
	String key;
	int value;
	
	HashNode next;
	
	HashNode(String key, int value)
	{
		this.key = key;
		this.value = value;
		this.next = null;
	}
	
}
