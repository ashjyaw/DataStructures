package cis113hash;

import java.util.*;

public class ChainedHashNode 
{
	private int tableSize;
	private int size;
	private HashNode[] bucket;
	
	public ChainedHashNode(int tableSize) 
	{
		size = 0;			// set size to 0 initially
		this.tableSize = tableSize; // set the table size
		bucket = new HashNode[tableSize]; // create a new hashnode array with length passed in
		
		for(int i = 0; i < tableSize; i++)
		{
			bucket[i] = null;
		}
		
	}
	
	// getters
	
	public int getSize()
	{
		return size;
	}
	
	public void whipeOut()
	{
		for(int i = 0; i < tableSize; i++)
		{
			bucket[i] = null;
		}
	}

	public void insert(String next, int nextInt) 
	{
		// TODO Auto-generated method stub
		int hash = next.hashCode() % tableSize;
		if(bucket[hash] == null)
		{
			bucket[hash] = new HashNode(next, nextInt);
		}
		else
		{
			HashNode entry = bucket[hash];
			while(entry.next != null && !entry.key.equals(next))
			{
				entry = entry.next;
			}
			if(entry.key.equals(next))
			{
				entry.value = nextInt;
			}
			else
			{
				entry.next = new HashNode(next, nextInt);
			}	
		}
		size++; // increase the size in here so when getsize is called its correct
	}

	public void remove(String next) 
	{
		// TODO Auto-generated method stub
		int hash = next.hashCode() % tableSize;
		if(bucket[hash] == null)
		{
			HashNode prevEntry = null;
			HashNode entry = bucket[hash];
			while(entry.next != null && !entry.key.equals(next))
			{
				prevEntry = entry;
				entry = entry.next;
			}
			if(entry.key.equals(next))
			{
				if(prevEntry == null)
				{
					bucket[hash] = entry.next;
				}
				else
				{
					prevEntry.next = entry.next;
				}
				size--;
			}
		}
	}

	public int get(String next) 
	{
		// TODO Auto-generated method stub
		int hash = next.hashCode() % tableSize;
		if(bucket[hash] == null)
		{
			return -1;
		}
		else
		{
			HashNode entry = bucket [hash];
			while(entry != null && !entry.key.equals(next))
			{
				entry = entry.next;
			}
			if(entry == null)
			{
				return -1;
			}
			else 
			{
				return entry.value;
			}
		}
	}

	public void print() 
	{
		// TODO Auto-generated method stub
		for(int i = 0; i < tableSize; i++)
		{
			System.out.print("\nBucket " + (i+1) + " : ");
			HashNode entry = bucket[i];
			if(entry == null)
			{
				System.out.println("Empty");
			}
			while(entry != null) 
			{
				System.out.print(entry.value + " ");
				entry = entry.next;
			}
			
		}
	}
	
	
	
}
