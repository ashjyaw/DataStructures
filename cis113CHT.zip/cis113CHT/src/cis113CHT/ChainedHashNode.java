package cis113CHT;

public class ChainedHashNode {
	
	String key; // our key
	int value; 	// our value stored in that key
	
	ChainedHashNode next; // next
	
	ChainedHashNode(String next, int nextInt)// constructor
	{
		this.key = next; // constructor setting values to this object
		this.value = nextInt;
		this.next = null; //
	}
}
