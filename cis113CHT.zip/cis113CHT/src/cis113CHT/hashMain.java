/*
 * Programmer: Ash Yaw
 * 
 * Class: CIS 113 Data Structures
 * 
 * Purpose: implementing a chained hash table
 */


package cis113CHT;

import java.util.Scanner; // only library


	public class hashMain 
	{
	
	
	private int tableSize; // the size of the bucket
	private int size; // # of the datagroups being stored not the size of the list
	private ChainedHashNode[] bucket; // set that array up
	
	
	public hashMain(int tableSize) // initialized the bucket size 
	{
		size = 0;			// set size to 0 initially
		this.tableSize = tableSize; // set the private tableSize variable to table size  
		bucket = new ChainedHashNode[tableSize]; // create a object array with tableSize called bucket
		
		for(int i = 0; i < tableSize; i++)// this initialized every thing in bucket array to null
		{
			bucket[i] = null; // this is good habit anyways because you don't know what your operating system is storing at these data locations so just clear it in case 
		}
	}
	
	public int getSize() // just a getter
	{
		return size;
	}
	
	public void whipeOut()// same thing as the loop up top just sets everything to null
	{
		for(int i = 0; i < tableSize; i++)
		{
			bucket[i] = null;
		}
	}
	
	public void insert(String next, int nextInt) // this ones interesting it takes in a string that eclipse autolabeled as next and an int autolabeled as nextInt
	{
		// TODO Auto-generated method stub
		int hash = next.hashCode() % tableSize; //this is to find our hash value i found the algo online for this
		if(bucket[hash] == null)// if current buccket is null make a new chainedhash node with the values next and nextInt
		{
			bucket[hash] = new ChainedHashNode(next, nextInt);
		}
		else //some other code thats pretty self explanitory 
		{ 
			ChainedHashNode entry = bucket[hash]; // entry is = to the object at bucket[hash]
			while(entry.next != null && !entry.key.equals(next)) // algo i found online
			{
				entry = entry.next; 
			}
			if(entry.key.equals(next))
			{
				entry.value = nextInt;
			}
			else
			{
				entry.next = new ChainedHashNode(next, nextInt); // finally sets the object up
			}	
		}
		size++; // increase the size in here so when getSize() is called its correct
	}
	
	public void remove(String next) // just the opposite of insert I found part of this online and referenced it i didn't copy i just used its algorithm
	{
		// TODO Auto-generated method stu
	
		int hash = next.hashCode() % tableSize; //this is to find our hash value i found the algo online for this
		
		ChainedHashNode entry = bucket[hash];
		ChainedHashNode prevEntry = null;
		
		while(entry != null)
		{
			
			if(entry.key.equals(next))
			{
				break;
			}
			
			prevEntry = entry;
			entry = entry.next;
		}
		
		if(entry == null)
		{
			return;
		}
		size--;
		if(prevEntry != null)
			prevEntry.next = entry.next;
		else
			bucket[hash] = entry.next;

	}
	
	public int get(String next) 
	{
		// TODO Auto-generated method stub
		int hash = next.hashCode() % tableSize; // algo to get our hash
		if(bucket[hash] == null) // does it equal null at buckets[hash]
		{
			return -1; // 
		}
		else
		{
			ChainedHashNode entry = bucket[hash];// again with the entry algorithm to traverse and find
			while(entry != null && !entry.key.equals(next))
			{
				entry = entry.next;
			}
			if(entry == null)
			{
				return -1;
			}
			else 
			{
				return entry.value;// if we find return it
			}
		}
	}
	
	public void print() 
	{
		// TODO Auto-generated method stub
		for(int i = 0; i < tableSize; i++)	// simple loop to print objects
		{
			System.out.print("\nBucket " + (i+1) + ": ");
			ChainedHashNode entry = bucket[i];
			if(entry == null) // catch if the bucket is empty and print it
			{
				System.out.print("Empty");
			}
			while(entry != null)  // if its got values print them and stop when there isn't any more left in the bucket
			{
				System.out.print(entry.key + "," + entry.value + " "); 
				entry = entry.next;
			}
			System.out.println(); // give a new line space our the program menu more
			
		}
	}

	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("HashTable with Strings and Integers"); // describes what it is
		System.out.println("Enter size");
		
		hashMain buckets = new hashMain(scan.nextInt()); // make new object of the hashMain class and passes in the bucket size for the hash tabled labeled as tableSize
		
		
		char choice = 'Y'; // cause of infinite loop
		
		while(choice == 'Y' || choice == 'y')//Infinite loop until the user enters any word that doesn't start with Yy 
		{
			
			System.out.println("\nHashTable functions, Enter The Number of your Choice\n");// nice selection table to let you really see how the hash table works
			System.out.println("1. Insert");
			System.out.println("2. Wipe");
			System.out.println("3. Remove");
			System.out.println("4. Get");
			System.out.println("5. Size");
			
			int chosenInt = scan.nextInt(); // gets what ever number the user chooses
			
			switch(chosenInt) // switch was the best way to handle this menu in this situation
			{
			case 1:
				System.out.println("Enter key and value seperated by a space");
				buckets.insert(scan.next(), scan.nextInt()); // call the function of our object buckets called insert that inserts a datagroup into our Chained node hash table
				break; // exits the case
			case 2:
				buckets.whipeOut(); // whipes out the hash tables data just like it does when its initialized
				System.out.println("The entire hashTable has been cleared"); 
				break;
			case 3:
				System.out.println("Enter Key to be removed");
				buckets.remove(scan.next()); // again our object buckets calls the function remove
				break;
			case 4:
				System.out.println("Enter Key to retrieve data"); 
				System.out.println("Value: " + buckets.get(scan.next()));// the object buckets calls the function get
				break;
			case 5:
				System.out.println("The amount of datagroups you have is: " + buckets.getSize()); // getSize() was called by the buckets object
				break;
			default:
				System.out.println("Enter a real option next time"); // default to catch anything else
				break;
			}
			
			System.out.println("\n [Bucket #: key,value]\n"); //example of the output to show what each data point represents
			buckets.print(); // print what the buckets look like

			System.out.println("\nContinue Yes or No");
			choice = scan.next().charAt(0); //this way it only scans the first letter of what's entered
		}
		scan.close(); // close the scanner
	}

}
