module cis113CHT {
	
	/*
	 * This program is my take on a chained hash table
	 * this program allows the user to select the size of the hash table but when the getSize method is called it will only give you how many datagroups
	 * you have stored not the size of the hashtable as the user specifies that in the beginning of the program
	 * this is a hard implementation of a chained hash node table meaning only the scanner library is used
	 * 
	 * this allows multiple values to be stored at the same bucket rather than 1 in the regular hashtable
	 * 
	 * 
	 * 
	 */
}